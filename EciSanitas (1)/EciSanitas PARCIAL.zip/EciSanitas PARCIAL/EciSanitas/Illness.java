import java.util.ArrayList;

public class Illness {
	private String name;
	private String description;
	private ArrayList<Treatment> treatments;
}
