public class Treatment {
	private String name;
	private String description;
	private String duration;
}
