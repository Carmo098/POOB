public class Location {
	private String department;
	private String city;
}
