public class Office {
	private int number;
	private int type;
}
